package com.task;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarMain {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		CarInventery b = (CarInventery) context.getBean("e");
		String action;
		Scanner sr = new Scanner(System.in);
		System.out.println(" enter any one of these actions add,list,quit");
		action = sr.next();
		while (!action.equals("quit")) {

			switch (action) {
			case "add":

				System.out.println("enter the value for id=");
				b.setId(sr.nextInt());
				System.out.println("enter the value for make=");
				b.setName(sr.next());
				System.out.println("enter the value for model=");
				b.setModel(sr.next());

				CarDao dao = context.getBean("cdao", CarDao.class);
				dao.savecardet(b);
				System.out.println("data saved successfully");

				System.out.println("please enter action add,list,quit");
				action = sr.next();
				break;
			case "list":
				CarDao dao1 = context.getBean("cdao", CarDao.class);
				List<CarInventery> list1 = dao1.getAllEmployeesRowMapper();
				list1.forEach(carInfo -> System.out.println(carInfo));
				System.out.println("please enter action add,list,quit");
				action = sr.next();
				break;
			default:
				System.out.println("please enter action add,list,quit");
				action = sr.next();
			}
		}
		System.out.println("Goodbye!!!!");
	}

}