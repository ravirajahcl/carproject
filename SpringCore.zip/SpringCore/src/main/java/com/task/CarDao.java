package com.task;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class CarDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void savecardet(CarInventery car) {
		String insertcarInfo = "insert into cardet values(" + car.getId() + ",'" + car.getName() + "','"
				+ car.getModel() + "')";
		jdbcTemplate.update(insertcarInfo);
	}

	public List<CarInventery> getAllEmployeesRowMapper() {
		return jdbcTemplate.query("select * from cardet", new RowMapper<CarInventery>() {
			public CarInventery mapRow(ResultSet rs, int rownumber) throws SQLException {
				CarInventery e = new CarInventery();
				e.setId(rs.getInt(1));
				e.setName(rs.getString(2));
				e.setModel(rs.getString(3));

				return e;
			}
		});
	}
}
